# Cloudformation-Ansible-Scripts
Real world working version of cloudformation and ansible scripts. Good example of mapping, user parameters and conditional interdependent steps in CloudFormation. 
